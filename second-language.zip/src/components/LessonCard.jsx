

const LessonCard = () => {
    return (
        <div>
            <h1>Lesson of</h1>
        </div>
    );
};

export default LessonCard;